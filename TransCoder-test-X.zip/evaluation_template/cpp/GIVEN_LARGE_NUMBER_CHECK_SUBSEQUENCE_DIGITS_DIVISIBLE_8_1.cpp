// Copyright (c) 2019-present, Facebook, Inc.
// All rights reserved.
//
// This source code is licensed under the license found in the
// LICENSE file in the root directory of this source tree.
//

#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <fstream>
#include <iomanip>
#include <bits/stdc++.h>
using namespace std;
bool f_gold ( string str ) {
  int n = str . length ( );
  int dp [ n + 1 ] [ 10 ];
  memset ( dp, 0, sizeof ( dp ) );
  int arr [ n + 1 ];
  for ( int i = 1;
  i <= n;
  i ++ ) arr [ i ] = str [ i - 1 ] - '0';
  for ( int i = 1;
  i <= n;
  i ++ ) {
    dp [ i ] [ arr [ i ] % 8 ] = 1;
    for ( int j = 0;
    j < 8;
    j ++ ) {
      if ( dp [ i - 1 ] [ j ] > dp [ i ] [ ( j * 10 + arr [ i ] ) % 8 ] ) dp [ i ] [ ( j * 10 + arr [ i ] ) % 8 ] = dp [ i - 1 ] [ j ];
      if ( dp [ i - 1 ] [ j ] > dp [ i ] [ j ] ) dp [ i ] [ j ] = dp [ i - 1 ] [ j ];
    }
  }
  for ( int i = 1;
  i <= n;
  i ++ ) {
    if ( dp [ i ] [ 0 ] == 1 ) return true;
  }
  return false;
}


//TOFILL

int main() {
    int n_success = 0;
    vector<string> param0 {"n jcjfyMoJEK","70507","0000111","YjRiCqr","4730248784","010101110","nLJV duUNH","27","1000","L"};
    for(int i = 0; i < param0.size(); ++i)
    {
        if(isSubSeqDivisible(param0[i]) == f_gold(param0[i]))
        {
            n_success+=1;
        }
    }
    cout << "#Results:" << " " << n_success << ", " << param0.size();
    return 0;
}