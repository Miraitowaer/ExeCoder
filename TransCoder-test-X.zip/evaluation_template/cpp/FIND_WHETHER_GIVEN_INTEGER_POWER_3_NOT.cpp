// Copyright (c) 2019-present, Facebook, Inc.
// All rights reserved.
//
// This source code is licensed under the license found in the
// LICENSE file in the root directory of this source tree.
//

#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <fstream>
#include <iomanip>
#include <bits/stdc++.h>
using namespace std;
bool f_gold ( int n ) {
  return 1162261467 % n == 0;
}


//TOFILL

int main() {
    int n_success = 0;
    vector<int> param0 {1,3,27,9,-9,11,57,21,60,44};
    for(int i = 0; i < param0.size(); ++i)
    {
        if(check(param0[i]) == f_gold(param0[i]))
        {
            n_success+=1;
        }
    }
    cout << "#Results:" << " " << n_success << ", " << param0.size();
    return 0;
}