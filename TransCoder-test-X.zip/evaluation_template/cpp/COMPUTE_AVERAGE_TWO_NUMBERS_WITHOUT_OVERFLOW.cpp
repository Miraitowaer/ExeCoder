// Copyright (c) 2019-present, Facebook, Inc.
// All rights reserved.
//
// This source code is licensed under the license found in the
// LICENSE file in the root directory of this source tree.
//

#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <fstream>
#include <iomanip>
#include <bits/stdc++.h>
using namespace std;
int f_gold ( int a, int b ) {
  return ( a + b ) / 2;
}


//TOFILL

int main() {
    int n_success = 0;
    vector<int> param0 {1,6,75,51,19,82,72,48,12,41};
    vector<int> param1 {44,61,20,17,25,98,21,41,17,80};
    for(int i = 0; i < param0.size(); ++i)
    {
        if(compute_average(param0[i],param1[i]) == f_gold(param0[i],param1[i]))
        {
            n_success+=1;
        }
    }
    cout << "#Results:" << " " << n_success << ", " << param0.size();
    return 0;
}